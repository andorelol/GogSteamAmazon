import os
import sys

from . import messages

base_dir = os.path.dirname(messages.__file__)
sys.path.append(base_dir)
