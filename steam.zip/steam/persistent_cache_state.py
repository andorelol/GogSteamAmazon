class PersistentCacheState:
    def __init__(self):
        self.modified = False
